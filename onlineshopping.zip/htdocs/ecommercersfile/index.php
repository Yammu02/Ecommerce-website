<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce website using php and mysql</title>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="./style.css"></link>
</head>
<body>
    <!-- <h1>Hello</h1> -->
    <div class="container-fluid p-0">
    <nav class="navbar navbar-expand-lg navbar-light bg-info">
  <img src="./images/shopping.jpeg" alt="" class="logo">
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Products</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Register</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Contact</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"><i class="fa-solid fa-cart-shopping"></i><sup>1</sup></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">TotalPrice:100/-</a>
      </li>
      
    </ul>
    <form class="d-flex">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
<!-- second child -->
<nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
    <ul class="navbar-nav me-Auto">
    <li class="nav-item">
        <a class="nav-link" href="#">Welcome Guest</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Login</a>
      </li>
    </ul>
</nav>
<!-- third child -->
    <div class="bg-light">
        <h3 class="text-center">Hidden Store</h3>
        <p class="text-center">communication is at the heart of e-commerce and community</p>
    </div>
    <!-- fourth child -->
    <div class="row">
        <div class="col-md-10">
           
            <div class="row">
                <div class="col-md-4 mb-2"><div class="card">
  <img class="card-img-top" src="./images/apple.jpeg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-info">Add to cart</a>
    <a href="#" class="btn btn-secondary">view more</a>
  </div>
</div></div>
                <div class="col-md-4 mb-2"><div class="card">
  <img class="card-img-top" src="./images/gift1.jpeg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-info">Add to cart</a>
    <a href="#" class="btn btn-secondary">view more</a>
  </div>
</div></div>
                <div class="col-md-4 mb-2"><div class="card">
  <img class="card-img-top" src="./images/dairy1.jpeg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-info">Add to cart</a>
    <a href="#" class="btn btn-secondary">view more</a>
  </div>
</div>
    </div>
    <div class="col-md-4 mb-2"><div class="card">
  <img class="card-img-top" src="./images/watch1.jpeg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-info">Add to cart</a>
    <a href="#" class="btn btn-secondary">view more</a>
  </div>
</div>
    </div>
    <div class="col-md-4 mb-2"><div class="card">
  <img class="card-img-top" src="./images/saree2.jpeg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-info">Add to cart</a>
    <a href="#" class="btn btn-secondary">view more</a>
  </div>
</div>
            </div>
            <div class="col-md-4 mb-2"><div class="card">
  <img class="card-img-top" src="./images/orange.jpeg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-info">Add to cart</a>
    <a href="#" class="btn btn-secondary">view more</a>
  </div>
</div></div></div>
    </div>
    <div class="col-md-2">
        <div class="bg-info p-2 mb-2">
            <h4>Categories</h4>
            <ul class="list-group">
                <li class="list-group-item">Electronics</li>
                <li class="list-group-item">Fashion</li>
                <li class="list-group-item">Home & Kitchen</li>
                <li class="list-group-item">Books</li>
                <li class="list-group-item">Sports</li>
            </ul>
        </div>
        <div class="bg-light p-2 mb-2">
            <h4>Filters</h4>
            <form>
                <div class="form-group">
                    <label for="priceRange">Price Range</label>
                    <select class="form-control" id="priceRange">
                        <option>Under $50</option>
                        <option>$50 to $100</option>
                        <option>$100 to $200</option>
                        <option>$200 & Above</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="brand">Brand</label>
                    <select class="form-control" id="brand">
                        <option>Any</option>
                        <option>Apple</option>
                        <option>Samsung</option>
                        <option>Nike</option>
                        <option>Adidas</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-info btn-block">Apply Filters</button>
            </form>
        </div>
        <div class="bg-light p-2">
            <h4>Popular Products</h4
